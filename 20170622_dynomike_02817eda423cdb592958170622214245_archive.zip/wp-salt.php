<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'ByVgLHiDgv7tW2pNyud1DvgU2DDfJwiqoXirrImJhtTyI4Ifp8E2GgLMhWqDFuhG');
define('SECURE_AUTH_KEY',  'rB56KwBareY99Nt7K72boe25Dvvgu9yxcI68WV5RPu4aWowGiIixUQptSMEsBNMt');
define('LOGGED_IN_KEY',    'bpr1UsXvjqfwMHgH69MLUV45qT7bmq25Q0in64WEtdj5KQDqXRt4SYqSV3WVfmgh');
define('NONCE_KEY',        'JgwBJ3mwbM9hfsD3GBGQCTs5KMRVbsQhN0boHK7cJPFqBo9TzVAMFc1osbCSEwcd');
define('AUTH_SALT',        '2E4BUosfRPs65invGXWeS723RbQU8v5Jv0WnU64brp1f2U45LTnJuKpj8xc5FMUE');
define('SECURE_AUTH_SALT', 'h3amaQiaLgGUvWXNp19RjgXYhoFriaC8Tn0RPo6ywfJVvivoo8gQeEvXgPwJRFE6');
define('LOGGED_IN_SALT',   'y8zcThDu6VUw7oa4SeHfyBGfrxoYbMXELDd0atnnWInbTrt3W34DKyipI0mWbu9m');
define('NONCE_SALT',       'snWbADPJbWxmIgynTQwbCwdGUxq0f0VwDztpQPvXvb8brc72YEm3E6pm5VaLtcFd');
